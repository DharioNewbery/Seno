<script lang="ts">
  import Logo from "#lib/components/Logo.svelte";
  import { NOME_SISTEMA } from "#lib/config";

  let email = $state("");
  let enviando = $state(false);
  let enviado = $state(false);
  let erroMensagem = $state("");

  async function pedir(evento: SubmitEvent) {
    evento.preventDefault();
    enviando = true;
    erroMensagem = "";
    try {
      const res = await fetch("/api/recuperar-senha", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      // 202 sempre (silencioso: não revela se a conta existe).
      if (res.ok) {
        enviado = true;
        return;
      }
      const corpo = (await res.json().catch(() => null)) as {
        erro?: { mensagem?: string };
      } | null;
      erroMensagem = corpo?.erro?.mensagem ?? "Não foi possível enviar o pedido.";
    } catch {
      erroMensagem = "Sem comunicação com o servidor. Tente novamente.";
    } finally {
      enviando = false;
    }
  }
</script>

<main class="recuperar">
  <div class="marca">
    <Logo tamanho={32} />
    <h1>{NOME_SISTEMA}</h1>
  </div>

  {#if enviado}
    <section class="cartao">
      <h2>Pedido enviado</h2>
      <p>
        Se o e-mail estiver cadastrado, você receberá um link para redefinir a
        senha (válido por 1 hora). Verifique sua caixa de entrada.
      </p>
      <a class="voltar" href="/">Voltar ao login</a>
    </section>
  {:else}
    <form class="cartao" onsubmit={pedir}>
      <h2>Recuperar senha</h2>
      <p class="dica">
        Enviaremos um link de redefinição (uso único) para o seu e-mail.
      </p>
      <label>
        <span>E-mail</span>
        <input
          type="email"
          bind:value={email}
          autocomplete="email"
          required
          placeholder="voce@ufpa.br"
        />
      </label>
      {#if erroMensagem}
        <p class="erro" role="alert">{erroMensagem}</p>
      {/if}
      <button type="submit" disabled={enviando}>
        {enviando ? "Enviando..." : "Enviar link de redefinição"}
      </button>
      <a class="voltar" href="/">Voltar ao login</a>
    </form>
  {/if}
</main>

<style>
  .recuperar {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1.25rem;
    padding: 2rem;
  }

  .marca {
    display: flex;
    align-items: center;
    gap: 0.75rem;
  }

  .marca h1 {
    margin: 0;
    font-size: 1.6rem;
  }

  .cartao {
    width: 100%;
    max-width: 400px;
    background: var(--seno-white);
    border: 1px solid var(--seno-gray-300);
    border-radius: 12px;
    padding: 2rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .cartao h2 {
    margin: 0;
  }

  .dica {
    margin: 0;
    color: var(--seno-gray-500);
    font-size: 0.85rem;
  }

  label {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
  }

  label span {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--seno-gray-700);
  }

  input {
    border: 1px solid var(--seno-gray-300);
    border-radius: 8px;
    padding: 0.65rem 0.75rem;
    font-size: 1rem;
    background: var(--seno-gray-100);
  }

  input:focus {
    outline: 2px solid var(--seno-blue-500);
    outline-offset: 1px;
    border-color: var(--seno-blue-500);
  }

  button {
    background: var(--seno-blue-600);
    color: var(--seno-white);
    border: none;
    border-radius: 8px;
    padding: 0.75rem;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
  }

  button:hover {
    background: var(--seno-blue-700);
  }

  button:disabled {
    opacity: 0.6;
    cursor: wait;
  }

  .erro {
    margin: 0;
    color: var(--seno-red);
    font-size: 0.9rem;
  }

  .voltar {
    color: var(--seno-blue-600);
    font-size: 0.9rem;
    text-align: center;
  }
</style>
